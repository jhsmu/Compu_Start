<footer class="pie-pagina">
<div class="grupo1">
            <div class="box">
                <figure>
                    <a href=""><img src="./img/logo/logo.jfif" alt="Logo Techno Solutions"></a>
                </figure>
            </div>
            <div class="box">
                <h2>Sobre Nosotros</h2>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis iure cupiditate accusamus saepe quisquam mollitia, voluptatem aperiam voluptate commodi consequuntur.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis iure cupiditate accusamus saepe quisquam mollitia, voluptatem aperiam voluptate commodi consequuntur.</p>
            </div>
            <div class="box">
                <h2>Siguenos</h2>
                <div class="redes">
                    <a href="" class="fab fa-facebook"></a>
                    <a href="" class="fab fa-instagram"></a>
                    <a href="" class="fab fa-twitter"></a>
                </div>
            </div>
        </div>
        <div class="grupo2">
            <small>&copy; 2022 <b>Jhonatan Mena</b> --Todos Los Derechos Reservados</small>
        </div>
</footer>
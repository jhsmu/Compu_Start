<?php
    if(isset($_POST["sesion"])){
        header('location:login-registro.php');
    }

    session_start();
    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <link rel="stylesheet" href="./css/footer-header.css">
    <link rel="icon" type="image/png" sizes="16x16" href="./img/Logo/favicon-16x16.png">
    <title>Compu Start</title>
</head>

<body>
<header>
    <?php
        include(("./componentes/header.php"))
    ?>
</header>

<div class="container">
<div class="row mt-4 mb-4">
            <!-- card 1 -->
            <div class="col-md-4">
                <div class="card">
                    <figure>
                    <img src="./img/portatil.png" height="200px" class="card-img-top" alt="...">
                    </figure>
                    <div class="card-body">
                        <h5 class="card-title">Portátil Acer Nitro5 Gamer I5</h5>
                        <p class="card-text">Gamer Laptop Hacer Nitro5, Geforce RTX3060 graphics card, The perfect balance between performance and temperatures. <!--Ram 16gb, 256gb solid state hybrid drive + 1 tr hard drive. Keyboard in Spanish and it's RGB--></p>
                        <a href="#" class="btn btn-primary">Ver mas</a>
                    </div>
                </div>
            </div>
            <!-- card 2 -->
            <div class="col-md-4">
                <div class="card">
                    <figure>
                    <img src="./img/portatil2.png" height="200px" class="card-img-top" alt="...">
                    </figure>
                    <div class="card-body">
                        <h5 class="card-title">Gamer AX-6 (Ó X15)</h5>
                        <p class="card-text">TORRE AX-6 (OR X15) GAMER, Gamer AX-6 (OR X15) with tempered side glass22" FHD LED MONITOR, GAMER KEYBOARD AND MOUSE.</p>
                        <a href="#" class="btn btn-primary">Ver mas</a>
                    </div>
                </div>
            </div>
            <!-- card 3 -->
            <div class="col-md-4">
                <div class="card">
                    <figure>
                    <img src="./img/portatil3.png" height="200px" class="card-img-top" alt="...">
                    </figure>
                    <div class="card-body">
                        <h5 class="card-title">Computador Portátil Gamer Victus HP 15.6</h5>
                        <p class="card-text">Play to the fullest with the Victus Gaming Laptop! Thanks to its modern components and lots of memory.

                         </p>
                        <a href="#" class="btn btn-primary">Ver mas</a>
                    </div>
                </div>
            </div>
            <!-- carusel -->
            <div id="carouselExampleAutoplaying" class="carousel slide mt-3 mb-3" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="https://www.notebookcheck.net/fileadmin/Notebooks/News/_nc3/4893391_15899281063797455_origin.jpg" height="250px" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="https://hardzone.es/app/uploads-hardzone.es/2022/02/Intel-vs-AMD-2022.jpg" height="250px" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="https://www.notebookcheck.net/fileadmin/Notebooks/News/_nc3/Intel_Xeon_Roadmap_Ice_Lake_Sapphire_Rapids_Granite_Rapids_5_2060x1159.png" height="250px" class="d-block w-100" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
            </div>
            <!-- card 4 -->
            <div class="col-md-4">
                <div class="card">
                    <figure>
                    <img src="./img/portatil4.png" height="200px" class="card-img-top" alt="...">
                    </figure>
                    <div class="card-body">
                        <h5 class="card-title">Computador Pc De Escritorio Torre Gamer </h5>
                        <p class="card-text">contains an operating system
                        windows 10 with
                        Ram Memory
                        16 GB, and accessories such as LIGHT GAMER KEYBOARD MOUSE .</p>
                        <a href="#" class="btn btn-primary">Ver mas</a>
                    </div>
                </div>
            </div>
            <!-- card 5 -->
            <div class="col-md-4">
                <div class="card">
                    <figure>
                    <img src="./img/portatil5.png" height="200px" class="card-img-top" alt="...">
                    </figure>
                    <div class="card-body">
                        <h5 class="card-title">ASUS Chromebook Enterprise</h5>
                        <p class="card-text">provides a simple and secure way to manage your Chrome OS devices and easily unfold and rotate the touchscreen into tent mode.</p>
                        <a href="#" class="btn btn-primary">Ver mas</a>
                    </div>
                </div>
            </div>
            <!-- card 6 -->
            <div class="col-md-4">
                <div class="card">
                    <figure>
                    <img src="./img/portatil6.png" height="200px" class="card-img-top" alt="...">
                    </figure>
                    <div class="card-body">
                        <h5 class="card-title">Lenovo Laptop IdeaPad 1</h5>
                        <p class="card-text">Effortless connection: enjoy a smoother wireless experience with Wi-Fi 6 (2x2) and 1TB storage and 20GB RAM: enjoy up to 15x faster performance.</p>
                        <a href="#" class="btn btn-primary">Ver mas</a>
                    </div>
                </div>
            </div>
        </div>
</div>


<footer class="pie-pagina">
<?php
        include(("./componentes/footer.php"))
?>
</footer>
</body>

</html>